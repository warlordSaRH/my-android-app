package com.example.mutajri;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
    final int GREEN = Color.rgb(22,138,74);
    final int DARK_GREEN = Color.rgb(18,107,59);
    final int PALE = Color.rgb(243,251,245);
    final int TEXT = Color.rgb(25,45,33);

    LinearLayout root, content;
    android.content.SharedPreferences prefs;

    JSONArray products() {
        try { return new JSONArray(prefs.getString("products","[]")); }
        catch(Exception e) { return new JSONArray(); }
    }
    JSONArray sales() {
        try { return new JSONArray(prefs.getString("sales","[]")); }
        catch(Exception e) { return new JSONArray(); }
    }
    void save(String key, JSONArray a) { prefs.edit().putString(key,a.toString()).apply(); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("mutajri", MODE_PRIVATE);
        buildShell();
        showHome();
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(4,4,4,4);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(15); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setBackgroundResource(com.example.mutajri.R.drawable.green_button);
        b.setPadding(10,2,10,2);
        return b;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(16,12,16,12);
        l.setBackgroundResource(R.drawable.card_bg);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PALE);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(18,10,18,10);
        bar.setBackgroundColor(DARK_GREEN);
        TextView title = tv("متجري",22,Color.WHITE,true);
        bar.addView(title,new LinearLayout.LayoutParams(0,64,1));
        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(14,14,14,8);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sc = new ScrollView(this);
        sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(6,4,6,6);
        nav.setBackgroundColor(Color.WHITE);
        String[] labels={"الرئيسية","المبيعات","المنتجات","التقارير"};
        for(String x:labels){
            Button n=btn(x); n.setTextColor(GREEN); n.setBackgroundColor(Color.TRANSPARENT);
            n.setOnClickListener(v -> {
                if(x.equals("الرئيسية")) showHome();
                else if(x.equals("المبيعات")) showSales();
                else if(x.equals("المنتجات")) showProducts();
                else showReports();
            });
            nav.addView(n,new LinearLayout.LayoutParams(0,58,1));
        }
        root.addView(nav);
        setContentView(root);
    }

    void clear(String title) {
        content.removeAllViews();
        TextView h=tv(title,24,TEXT,true);
        h.setPadding(4,4,4,12);
        content.addView(h);
    }

    void addSpace(int h){ Space s=new Space(this); content.addView(s,new LinearLayout.LayoutParams(1,h)); }

    double todaySales() {
        double total=0; JSONArray a=sales();
        for(int i=0;i<a.length();i++) try { total += a.getDouble(i); } catch(Exception ignored){}
        return total;
    }

    void showHome() {
        clear("السلام عليكم 👋");
        LinearLayout c=card();
        c.addView(tv("مبيعات اليوم",14,Color.DKGRAY,false));
        c.addView(tv(String.format(Locale.US,"%.0f ج.س",todaySales()),28,GREEN,true));
        content.addView(c,new LinearLayout.LayoutParams(-1,110));
        addSpace(12);

        LinearLayout row=new LinearLayout(this); row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout a=card(); a.addView(tv("المنتجات",14,Color.DKGRAY,false)); a.addView(tv(""+products().length(),26,GREEN,true));
        LinearLayout b=card(); b.addView(tv("عمليات البيع",14,Color.DKGRAY,false)); b.addView(tv(""+sales().length(),26,GREEN,true));
        row.addView(a,new LinearLayout.LayoutParams(0,110,1)); row.addView(b,new LinearLayout.LayoutParams(0,110,1));
        content.addView(row); addSpace(14);

        Button sell=btn("🛒  تسجيل بيع"); sell.setOnClickListener(v->showSales()); content.addView(sell,new LinearLayout.LayoutParams(-1,60));
        addSpace(8);
        Button add=btn("📦  إضافة بضاعة"); add.setOnClickListener(v->addProductDialog()); content.addView(add,new LinearLayout.LayoutParams(-1,60));
        addSpace(8);
        Button inv=btn("🔍  جرد المخزون"); inv.setOnClickListener(v->showProducts()); content.addView(inv,new LinearLayout.LayoutParams(-1,60));
        addSpace(14);

        LinearLayout low=card(); low.addView(tv("أصناف المخزون",16,TEXT,true));
        JSONArray p=products();
        if(p.length()==0) low.addView(tv("لم تتم إضافة منتجات بعد.",14,Color.DKGRAY,false));
        else for(int i=0;i<p.length();i++) try {
            JSONObject o=p.getJSONObject(i);
            low.addView(tv(o.getString("name")+"  —  "+o.getInt("qty")+" متوفر",14,o.getInt("qty")<=3?Color.rgb(180,110,0):TEXT,false));
        }catch(Exception ignored){}
        content.addView(low);
    }

    void showProducts() {
        clear("المنتجات");
        Button add=btn("+  إضافة منتج"); add.setOnClickListener(v->addProductDialog()); content.addView(add,new LinearLayout.LayoutParams(-1,58)); addSpace(10);
        JSONArray p=products();
        if(p.length()==0) { content.addView(tv("لا توجد منتجات. ابدأ بإضافة أول منتج.",16,TEXT,false)); return; }
        for(int i=0;i<p.length();i++) try {
            JSONObject o=p.getJSONObject(i);
            LinearLayout c=card();
            c.addView(tv(o.getString("name"),18,TEXT,true));
            c.addView(tv("سعر البيع: "+o.getDouble("price")+" ج.س   •   المخزون: "+o.getInt("qty"),14,Color.DKGRAY,false));
            content.addView(c,new LinearLayout.LayoutParams(-1,88)); addSpace(7);
        }catch(Exception ignored){}
    }

    void showSales() {
        clear("تسجيل بيع");
        JSONArray p=products();
        if(p.length()==0){ content.addView(tv("أضف منتجات أولاً حتى تتمكن من تسجيل البيع.",16,TEXT,false)); return; }
        final Spinner sp=new Spinner(this);
        String[] names=new String[p.length()];
        for(int i=0;i<p.length();i++) try{names[i]=p.getJSONObject(i).getString("name");}catch(Exception e){names[i]="منتج";}
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));
        content.addView(tv("اختر المنتج",15,TEXT,true)); content.addView(sp,new LinearLayout.LayoutParams(-1,58)); addSpace(8);

        EditText q=new EditText(this); q.setHint("الكمية"); q.setInputType(2); q.setText("1"); q.setGravity(Gravity.RIGHT);
        content.addView(q,new LinearLayout.LayoutParams(-1,58)); addSpace(10);

        Button record=btn("تسجيل البيع"); record.setOnClickListener(v->{
            try{
                int idx=sp.getSelectedItemPosition(), qty=Integer.parseInt(q.getText().toString());
                JSONObject o=p.getJSONObject(idx); int stock=o.getInt("qty");
                if(qty<=0 || qty>stock){ Toast.makeText(this,"الكمية غير متاحة.",Toast.LENGTH_SHORT).show(); return; }
                double total=o.getDouble("price")*qty;
                o.put("qty",stock-qty); p.put(idx,o); save("products",p);
                JSONArray s=sales(); s.put(total); save("sales",s);
                Toast.makeText(this,"تم تسجيل البيع بنجاح ✓",Toast.LENGTH_SHORT).show();
                showHome();
            }catch(Exception e){Toast.makeText(this,"تحقق من البيانات.",Toast.LENGTH_SHORT).show();}
        });
        content.addView(record,new LinearLayout.LayoutParams(-1,60));
    }

    void showReports() {
        clear("التقارير");
        LinearLayout c=card();
        c.addView(tv("إجمالي المبيعات المسجلة",15,Color.DKGRAY,false));
        c.addView(tv(String.format(Locale.US,"%.0f ج.س",todaySales()),30,GREEN,true));
        c.addView(tv("عدد عمليات البيع: "+sales().length(),15,TEXT,false));
        content.addView(c,new LinearLayout.LayoutParams(-1,145)); addSpace(12);
        content.addView(tv("نسخة MVP: هذه الشاشة تعرض إجمالي المبيعات. لاحقاً نضيف الأرباح والمصروفات والتقارير اليومية/الأسبوعية.",14,Color.DKGRAY,false));
    }

    void addProductDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,4,8,4);
        EditText name=new EditText(this); name.setHint("اسم المنتج"); name.setGravity(Gravity.RIGHT);
        EditText price=new EditText(this); price.setHint("سعر البيع"); price.setInputType(2); price.setGravity(Gravity.RIGHT);
        EditText qty=new EditText(this); qty.setHint("الكمية"); qty.setInputType(2); qty.setGravity(Gravity.RIGHT);
        box.addView(name); box.addView(price); box.addView(qty);
        new AlertDialog.Builder(this).setTitle("إضافة منتج").setView(box)
            .setNegativeButton("إلغاء",null)
            .setPositiveButton("حفظ",(d,w)->{
                try{
                    String n=name.getText().toString().trim(); double pr=Double.parseDouble(price.getText().toString()); int q=Integer.parseInt(qty.getText().toString());
                    if(n.isEmpty()||pr<0||q<0) throw new Exception();
                    JSONObject o=new JSONObject(); o.put("name",n); o.put("price",pr); o.put("qty",q);
                    JSONArray p=products(); p.put(o); save("products",p); showProducts();
                }catch(Exception e){Toast.makeText(this,"أدخل بيانات صحيحة.",Toast.LENGTH_SHORT).show();}
            }).show();
    }
}
